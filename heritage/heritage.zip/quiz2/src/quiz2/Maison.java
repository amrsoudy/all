package quiz2;

public class Maison extends Batiment1 {
	
	private int nbPices;

	public int getNbPices() {
		return nbPices;
	}

	public void setNbPices(int nbPices) {
		this.nbPices = nbPices;
	}

	

}
